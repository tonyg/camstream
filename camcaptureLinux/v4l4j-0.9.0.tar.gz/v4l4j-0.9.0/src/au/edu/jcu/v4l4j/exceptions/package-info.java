/**
 * <h1>Video4Linux4java exception Package</h1>
 */
package au.edu.jcu.v4l4j.exceptions;
